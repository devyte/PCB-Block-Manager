Board name and part number= Block Manager Rev C

For company = TBD
Bare Board Quantity = 25 pcs
Ship via= UPS or Fedex

PCB = FR4, .063" maximum thickness, 94V0 rated, Tg=170C
Layers =  2 layers copper, 
	and Silkscreen legend- Top and Bottom and 
	soldermask both sides- Top and Bottom

SPECIAL REQUESTS = 

-- Please check Gerber files and compare with IPC-D356 netlist in gerber zip folder

Copper = 1 oz copper minimum, holes must be thru-hole plated 1oz copper min
	
Finish = No lead solder for ROHS compatibility, hot air leveled. 


Solder mask color = Green LPI TIM MAKE BLUE NEXT RUN
Solder mask layers =  top and bottom layers
Silk screen = White silkscreen on top and bottom layers

Gerber Files for processing:
Block Manager Rev C.comp (top layer copper)
Block Manager Rev C.sol (bottom layer copper)
Block Manager Rev C.plc (top silkscreen layer)
Block Manager Rev C.botplc (bottom silkscreen layer)
Block Manager Rev C.stc (top soldermask)
Block Manager Rev C.sts (bottom soldermask)


Excellon Drill filles:
Block Manager Rev C.dri (holes sizes and number)
Block Manager Rev C.drd (hole locations)

IPC netlist file:
Block Manager Rev C.ipc


Assembly Drawing:
Block Manager Rev C Assembly drawing.pdf

BOM:
Block Manager Rev C BOM.pdf

CAD files for pick and place:
Block Manager Rev C.fab	(fabmaster.ulp)
Block Manager Rev C.CAD  (Gencad.ulp)


Bare board electrical testing = YES, Required

CONTACT

TBD